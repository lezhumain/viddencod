CURRENT
-------

This win32 build is from http://ffmpeg.zeranoe.com/builds/ (FFmpeg git-a254452 - compiled 2011-09-19)
Sources, licenses, etc can be found there or at http://ffmpeg.org/download.html

